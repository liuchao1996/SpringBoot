package com.lc.springbootlession7.mapping;

import org.apache.ibatis.mapping.VendorDatabaseIdProvider;

public class MyVendorDatabaseIdProvider extends VendorDatabaseIdProvider {

}
