package com.lc.springbootlession7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLession7Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootLession7Application.class, args);
	}
}
